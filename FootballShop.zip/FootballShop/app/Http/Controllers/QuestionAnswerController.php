<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\QuestionAnsweringService;

class QuestionAnswerController extends Controller
{
    public function ask(Request $request, QuestionAnsweringService $qa)
    {
        $question = $request->input('question');
        $answer = $qa->answer($question);

        return response()->json(['answer' => $answer]);
    }

}
