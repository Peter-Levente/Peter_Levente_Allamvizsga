<?php

namespace App\Listeners;

use App\Events\ProductViewed;
use App\Services\UserInterestProfileUpdater;

class UpdateUserProfileOnView
{
    public function handle(ProductViewed $event): void
    {
        app(UserInterestProfileUpdater::class)->update($event->userId);
    }
}
