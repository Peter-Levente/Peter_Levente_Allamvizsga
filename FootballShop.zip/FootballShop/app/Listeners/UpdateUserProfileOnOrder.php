<?php

namespace App\Listeners;

use App\Events\OrderPlaced;
use App\Services\UserInterestProfileUpdater;

class UpdateUserProfileOnOrder
{
    public function handle(OrderPlaced $event): void
    {
        app(UserInterestProfileUpdater::class)->update($event->userId);
    }
}

