<?php

namespace App\Listeners;

use App\Events\ProductAddedToCart;
use App\Services\UserInterestProfileUpdater;

class UpdateUserProfileOnCartAdd
{
    public function handle(ProductAddedToCart $event): void
    {
        app(UserInterestProfileUpdater::class)->update($event->userId);
    }
}
