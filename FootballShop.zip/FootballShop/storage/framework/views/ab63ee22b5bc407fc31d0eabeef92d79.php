<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Cart</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/cart.css')); ?>">
</head>
<body>
<div class="container">
    <header>
        <nav class="navbar">
            <div>
                <h1>My Cart</h1>
            </div>
            <div>
                <a href="<?php echo e(url('/')); ?>">Home</a>
            </div>
        </nav>
    </header>

    <main class="cart-page">
        <h2 class="cart-title">Your Shopping Cart</h2>

        <?php if($cartItems->isNotEmpty()): ?>
            <table class="cart-table">
                <thead>
                <tr>
                    <th>Product</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Size</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img src="<?php echo e(asset($item->product->image)); ?>" alt="<?php echo e($item->product->name); ?>"></td>
                        <td class="item-name"><?php echo e($item->product->name); ?></td>
                        <td class="item-price"><?php echo e(number_format($item->product->price, 2)); ?> lei</td>
                        <td class="item-size"><?php echo e(session('size_' . $item->product->id)); ?></td>
                        <td class="item-quantity">
                            <form method="post" action="<?php echo e(route('cart.update', $item->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="hidden" name="cart_id" value="<?php echo e($item->id); ?>">
                                <input type="number" name="quantity" value="<?php echo e($item->quantity); ?>" min="1" onchange="this.form.submit()">
                            </form>
                        </td>

                        <td class="item-total"><?php echo e(number_format($item->product->price * $item->quantity, 2)); ?> lei</td>
                        <td>
                            <form method="post" action="<?php echo e(route('cart.remove', $item->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit">Remove</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class="cart-total">
                Total: <?php echo e(number_format($totalPrice, 2)); ?> lei
            </div>

            <div class="cart-buttons">
                <button onclick="location.href='<?php echo e(route('cart.checkout')); ?>'">Checkout</button>
                <button onclick="location.href='<?php echo e(url('/')); ?>'">Continue Shopping</button>
            </div>
        <?php else: ?>
            <p class="empty-cart">Your cart is empty!</p>
        <?php endif; ?>

        <?php if(!empty($similarProducts)): ?>
            <section class="related-products">
                <h3>Hasonló termékek, amik érdekelhetnek</h3>
                <div class="product-grid">
                    <?php $__currentLoopData = $similarProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('products.details', ['id' => $similar->id])); ?>" class="product-card">
                            <img src="<?php echo e(asset($similar->image)); ?>" alt="<?php echo e($similar->name); ?>">
                            <h4><?php echo e($similar->name); ?></h4>
                            <p><?php echo e(number_format($similar->price, 2)); ?> lei</p>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>


        <?php if($recommendedProducts->isNotEmpty()): ?>
            <section class="recommended-cross-sell">
                <h3>🛍️ Ezt még érdemes megnézned</h3>
                <div class="product-grid">
                    <?php $__currentLoopData = $recommendedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('products.details', ['id' => $product->id])); ?>" class="product-card">
                            <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>">
                            <h4><?php echo e($product->name); ?></h4>
                            <p><?php echo e(number_format($product->price, 2)); ?> lei</p>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>


    </main>
</div>
</body>
</html>
<?php /**PATH D:\SAPIENTIA\ÁLLAMVIZSGA\Peter_Levente_Allamvizsga\FootballShop\resources\views/cart/mycart.blade.php ENDPATH**/ ?>