<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Football Shop - Product</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/PROJECT.css')); ?>">
</head>
<body>
<div class="wrapper">
    <header>
        <nav class="header">
            <div class="title">
                <h1>Football Shop</h1>

                <div class="auth-buttons">
                    <?php if(!auth()->check()): ?>
                        <!-- Ha nincs bejelentkezve -->
                        <a href="<?php echo e(route('login')); ?>"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
                        <a href="<?php echo e(route('register')); ?>"><i class="fa-solid fa-user-plus"></i> Registration</a>
                    <?php endif; ?>
                </div>

                <div class="auth-buttons">
                    <?php if(auth()->check()): ?>
                        <!-- Ha be van jelentkezve -->
                        <a href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="fa-solid fa-right-from-bracket"></i> Logout
                        </a>

                        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>

                        <span class="welcome-message">Welcome, <?php echo e(auth()->user()->name); ?>!</span>
                    <?php endif; ?>
                </div>

                <div class="header-actions">
                    <?php if(!Request::is('/')): ?>
                        <a href="<?php echo e(url('/')); ?>" class="home-link">
                            <i class="fa-solid fa-house"></i> Home
                        </a>
                    <?php endif; ?>

                    <?php if(auth()->check()): ?>
                        <a id="cart-icon" href="<?php echo e(route('cart.mycart')); ?>" class="header-link">
                            <i class="fa-solid fa-basket-shopping"></i> My Cart
                        </a>
                        <a id="orders-icon" href="<?php echo e(route('orders.myorders')); ?>" class="header-link">
                            <i class="fa-solid fa-box"></i> My Orders
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="menu">
                <a href="<?php echo e(route('products.category', ['category' => 'Clothings'])); ?>">Club Apparel</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Jerseys'])); ?>">Club Jerseys</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Shoes'])); ?>">Football Shoes</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Balls'])); ?>">Football Balls</a>
            </div>
        </nav>
    </header>

    <main>
        <?php if(isset($product)): ?>
            <div class="product-details">
                <div class="product-image">
                    <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>">
                </div>
                <div class="product-info">
                    <h2><?php echo e($product->name); ?></h2>
                    <p class="price"><?php echo e(number_format($product->price, 2)); ?> lei</p>
                    <p class="description"><?php echo e($product->description); ?>TERMEK_LEIRAS</p> <!-- Leírás hozzáadása -->

                    <form action="<?php echo e(route('cart.add', ['product' => $product->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">

                        <?php if($product->category != 'Equipment'): ?>
                            <label for="size">Size:</label>
                            <select name="size" id="size" required>
                                <option value="" selected disabled>Select size</option> <!-- Alapértelmezett üres opció -->
                                <?php if($product->category == 'Shoes'): ?>
                                    <option value="38">38</option>
                                    <option value="38.5">38.5</option>
                                    <option value="39">39</option>
                                    <option value="40">40</option>
                                    <option value="40.5">40.5</option>
                                    <option value="41">41</option>
                                    <option value="42">42</option>
                                    <option value="42.5">42.5</option>
                                    <option value="43">43</option>
                                    <option value="44">44</option>
                                    <option value="44.5">44.5</option>
                                    <option value="45">45</option>
                                    <option value="45.5">45.5</option>
                                    <option value="46">46</option>
                                    <option value="47">47</option>
                                    <option value="47.5">47.5</option>
                                <?php elseif($product->category == 'Balls'): ?>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                <?php else: ?>
                                    <option value="S">S</option>
                                    <option value="M">M</option>
                                    <option value="L">L</option>
                                    <option value="XL">XL</option>
                                    <option value="XXL">XXL</option>
                                <?php endif; ?>
                            </select>
                        <?php endif; ?>

                        <label for="quantity">Quantity:</label>
                        <input type="number" name="quantity" id="quantity" min="1" max="50" value="1" required>
                        <button type="submit">Add to Cart</button>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <p>Product not found.</p>
        <?php endif; ?>

        <?php if(!empty($similarProducts)): ?>
            <section class="related-products">
                <h3>Hasonló termékek, amik érdekelhetnek</h3>
                <div class="product-grid">
                    <?php $__currentLoopData = $similarProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('products.details', ['id' => $similar->id])); ?>" class="product-card">
                            <img src="<?php echo e(asset($similar->image)); ?>" alt="<?php echo e($similar->name); ?>">
                            <h4><?php echo e($similar->name); ?></h4>
                            <p><?php echo e(number_format($similar->price, 2)); ?> lei</p>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>
    </main>


    <footer>
        <div class="footer">
            <p>All rights reserved ©Football Shop 2025</p>
        </div>
    </footer>

    
    <?php echo $__env->make('components.chatbot-widget', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
</body>
</html>
<?php /**PATH D:\SAPIENTIA\ÁLLAMVIZSGA\Peter_Levente_Allamvizsga\FootballShop\resources\views/products/details.blade.php ENDPATH**/ ?>