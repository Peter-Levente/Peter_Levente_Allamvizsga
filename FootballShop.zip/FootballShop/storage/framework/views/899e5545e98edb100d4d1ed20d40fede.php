<!-- resources/views/product.details.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Football Shop - Product</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="index-page category-page product-page">
<div class="wrapper">
    <header>
        <nav class="header">
            <div class="topbar">
                <div class="center">
                    <h1>Football Shop</h1>
                </div>

                <!-- Mobil ikon-sáv -->
                <div class="icon-bar">
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">☰</button>

                    <a href="<?php echo e(url('/')); ?>"><i class="fa-solid fa-house"></i> <span></span></a>

                    <?php if(!auth()->check()): ?>
                        <a href="<?php echo e(route('login')); ?>"><i class="fa-solid fa-right-to-bracket"></i></a>
                        <a href="<?php echo e(route('register')); ?>"><i class="fa-solid fa-user-plus"></i></a>
                    <?php else: ?>
                        <a href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="fa-solid fa-right-from-bracket"></i>
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    <?php endif; ?>
                    <a href="<?php echo e(route('orders.myorders')); ?>"><i class="fa-solid fa-box"></i></a>
                    <a href="<?php echo e(route('cart.mycart')); ?>"><i class="fa-solid fa-cart-shopping"></i></a>

                    <button type="button" class="search-toggle" onclick="toggleMobileSearchBar()">
                        <i class="fa fa-search"></i>
                    </button>

                    <form method="GET" action="<?php echo e(route('home')); ?>" id="mobile-search-bar" class="search-form">
                        <input type="text" name="search" placeholder="Search products" value="<?php echo e(request('search')); ?>">
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </form>
                </div>

                <div class="left">
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">☰</button>
                    <div class="auth-buttons">
                        <?php if(!auth()->check()): ?>
                            <a href="<?php echo e(route('login')); ?>"><i class="fa-solid fa-right-to-bracket"></i>
                                <span>Login</span></a>
                            <a href="<?php echo e(route('register')); ?>"><i class="fa-solid fa-user-plus"></i>
                                <span>Registration</span></a>
                        <?php else: ?>
                            <a href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fa-solid fa-right-from-bracket"></i> <span>Logout</span>
                            </a>
                            <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>"
                                  style="display: none;"><?php echo csrf_field(); ?></form>
                            <span class="welcome-message">Welcome, <?php echo e(auth()->user()->name); ?>!</span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="right">
                    <div class="header-actions">
                        <div class="search-container">
                            <button type="button" class="search-toggle" onclick="toggleSearchBar()">
                                <i class="fa fa-search"></i>
                            </button>
                            <form method="GET" action="<?php echo e(route('home')); ?>" id="search-bar" class="search-form">
                                <input type="text" name="search" placeholder="Search products"
                                       value="<?php echo e(request('search')); ?>">
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>

                        <a href="<?php echo e(url('/')); ?>"><i class="fa-solid fa-house"></i> <span>Home</span></a>

                        <?php if(auth()->check()): ?>
                            <a href="<?php echo e(route('cart.mycart')); ?>"><i class="fa-solid fa-basket-shopping"></i> <span>My Cart</span></a>
                            <a href="<?php echo e(route('orders.myorders')); ?>"><i class="fa-solid fa-box"></i>
                                <span>My Orders</span></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="menu">
                <a href="<?php echo e(route('products.category', ['category' => 'Clothings'])); ?>">Club Apparel</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Jerseys'])); ?>">Club Jerseys</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Shoes'])); ?>">Football Shoes</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Balls'])); ?>">Football Balls</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Equipment'])); ?>">Football Equipment</a>
            </div>

            <div class="mobile-menu">
                <a href="<?php echo e(route('products.category', ['category' => 'Clothings'])); ?>">Club Apparel</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Jerseys'])); ?>">Club Jerseys</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Shoes'])); ?>">Football Shoes</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Balls'])); ?>">Football Balls</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Equipment'])); ?>">Football Equipment</a>
            </div>
        </nav>
    </header>

    <main>
        <?php if(isset($product)): ?>
            <div class="product-details">
                <div class="product-image">
                    <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>">
                </div>
                <div class="product-info">
                    <h2><?php echo e($product->name); ?></h2>
                    <p class="price">Price: <?php echo e(number_format($product->price, 2)); ?> lei</p>
                    <p class="description"><?php echo e($product->description); ?></p>

                    <form action="<?php echo e(route('cart.add', ['product' => $product->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">

                        <?php if($product->category != 'Equipment'): ?>
                            <label for="size">Size:</label>
                            <select name="size" id="size" required>
                                <option value="" selected disabled>Select size</option>
                                <!-- Alapértelmezett üres opció -->
                                <?php if($product->category == 'Shoes'): ?>
                                    <option value="38">38</option>
                                    <option value="38.5">38.5</option>
                                    <option value="39">39</option>
                                    <option value="40">40</option>
                                    <option value="40.5">40.5</option>
                                    <option value="41">41</option>
                                    <option value="42">42</option>
                                    <option value="42.5">42.5</option>
                                    <option value="43">43</option>
                                    <option value="44">44</option>
                                    <option value="44.5">44.5</option>
                                    <option value="45">45</option>
                                    <option value="45.5">45.5</option>
                                    <option value="46">46</option>
                                    <option value="47">47</option>
                                    <option value="47.5">47.5</option>
                                <?php elseif($product->category == 'Balls'): ?>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                <?php else: ?>
                                    <option value="S">S</option>
                                    <option value="M">M</option>
                                    <option value="L">L</option>
                                    <option value="XL">XL</option>
                                    <option value="XXL">XXL</option>
                                <?php endif; ?>
                            </select>
                        <?php endif; ?>

                        <label for="quantity">Quantity:</label>
                        <input type="number" name="quantity" id="quantity" min="1" max="50" value="1" required>
                        <button type="submit">Add to Cart</button>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <p>Product not found.</p>
        <?php endif; ?>

        <?php if(!empty($similarProducts)): ?>
            <section class="personal-recommendations">
                <h2>🎯 Hasonló termékek, amik érdekelhetnek</h2>
                <div class="recommendation-wrapper">
                    <button class="scroll-left" onclick="scrollRecommendations(-1)">&#10094;</button>

                    <div class="product-grid" id="recommendation-track">
                        <?php $__currentLoopData = $similarProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('products.details', ['id' => $product->id])); ?>" class="product-card">
                                <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>">
                                <h4><?php echo e($product->name); ?></h4>
                                <p><?php echo e(number_format($product->price, 2)); ?> lei</p>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <button class="scroll-right" onclick="scrollRecommendations(1)">&#10095;</button>
                </div>
            </section>
        <?php endif; ?>
    </main>

    <footer>
        <div class="footer">
            <p>All rights reserved ©Football Shop 2025</p>
        </div>
    </footer>

    <?php echo $__env->make('components.chatbot-widget', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
</body>
</html>
<?php /**PATH D:\SAPIENTIA\ÁLLAMVIZSGA\Peter_Levente_Allamvizsga\FootballShop\resources\views/products/details.blade.php ENDPATH**/ ?>