<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="my-orders-page">
<div class="container">
    <header>
        <h1>My Orders</h1>
        <a href="<?php echo e(url('/')); ?>">Home</a>
    </header>
    <main>
        <?php if($orders->isNotEmpty()): ?>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="order">
                    <h2>Order #<?php echo e($order->id); ?> (<?php echo e($order->created_at); ?>)</h2>
                    <p><strong>Name:</strong> <?php echo e($order->user->name); ?></p>
                    <p><strong>Email:</strong> <?php echo e($order->user->email); ?></p>
                    <p><strong>Address:</strong> <?php echo e($order->address); ?></p>
                    <p><strong>Phone:</strong> <?php echo e($order->phone); ?></p>
                    <p><strong>Payment Method:</strong> <?php echo e($order->payment_method); ?></p>
                    <p><strong>Total Amount:</strong> <?php echo e(number_format($order->total_amount, 2)); ?> lei</p>

                    <h3>Items:</h3>
                    <ul>
                        <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <img src="<?php echo e(asset($item->product->image)); ?>" alt="<?php echo e($item->product->name); ?>" style="width: 50px; height: 50px;">
                                <?php echo e($item->product->name); ?>

                                (Size: <?php echo e(session('size_' . $item->product->id)); ?>)
                                - <?php echo e($item->quantity); ?> pcs @ <?php echo e(number_format($item->product->price, 2)); ?> lei each
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <form method="post" action="<?php echo e(route('orders.destroy', $order->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Cancel Order</button>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p>You have no orders yet.</p>
        <?php endif; ?>
    </main>
</div>
</body>
</html>
<?php /**PATH D:\SAPIENTIA\ÁLLAMVIZSGA\Peter_Levente_Allamvizsga\FootballShop\resources\views/orders/myorders.blade.php ENDPATH**/ ?>