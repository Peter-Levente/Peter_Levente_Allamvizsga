<!-- resources/views/index.blade.php -->

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Football Shop - Home</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="index-page">
<div class="wrapper">
    <header>
        <nav class="header">
            <!-- FELSŐ SÁV: logó középen, bal/jobb oldalra a többi -->
            <div class="topbar">
                <!-- KÖZÉP: logó és mobilmenü gomb -->
                <div class="center">
                    <h1>Football Shop</h1>
                </div>

                <div class="icon-bar">
                    <!-- Menü ikon -->
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">☰</button>

                    <!-- Auth ikonok -->
                    <?php if(!auth()->check()): ?>
                        <a href="<?php echo e(route('login')); ?>">
                            <i class="fa-solid fa-right-to-bracket"></i>
                        </a>
                        <a href="<?php echo e(route('register')); ?>">
                            <i class="fa-solid fa-user-plus"></i>
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="fa-solid fa-right-from-bracket"></i>
                        </a>
                        <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    <?php endif; ?>


                    <button type="button" class="search-toggle" onclick="toggleMobileSearchBar()" aria-label="Keresés ikon">
                        <i class="fa fa-search"></i>
                    </button>

                    <form method="GET" action="<?php echo e(route('home')); ?>" id="mobile-search-bar" class="search-form">
                        <input type="text" name="search" placeholder="Search products" value="<?php echo e(request('search')); ?>">
                        <button type="submit" aria-label="Keresés">
                            <i class="fa fa-search"></i>
                        </button>
                    </form>


                    <!-- Kosár, rendelések -->
                    <?php if(auth()->check()): ?>
                        <a id="cart-icon" href="<?php echo e(route('cart.mycart')); ?>">
                            <i class="fa-solid fa-basket-shopping"></i>
                        </a>
                        <a id="orders-icon" href="<?php echo e(route('orders.myorders')); ?>">
                            <i class="fa-solid fa-box"></i>
                        </a>
                    <?php endif; ?>
                </div>

                <!-- BAL OLDAL: auth-gombok -->
                <div class="left">
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">
                        ☰
                    </button>


                    <div class="auth-buttons">
                        <?php if(!auth()->check()): ?>
                            <a href="<?php echo e(route('login')); ?>">
                                <i class="fa-solid fa-right-to-bracket"></i> <span>Login</span>
                            </a>
                            <a href="<?php echo e(route('register')); ?>">
                                <i class="fa-solid fa-user-plus"></i> <span>Registration</span>
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fa-solid fa-right-from-bracket"></i>
                                <span>Logout</span>
                            </a>

                            <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>

                            <span class="welcome-message">Welcome, <?php echo e(auth()->user()->name); ?>!</span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- JOBB OLDAL: kereső + cart + orders -->
                <div class="right">
                    <div class="header-actions">
                        <!-- 🔍 Közös keresőmező az oldal tetején -->
                        <div class="search-container">
                            <button type="button" class="search-toggle" onclick="toggleSearchBar()" aria-label="Keresés ikon">
                                <i class="fa fa-search"></i>
                            </button>

                            <form method="GET" action="<?php echo e(route('home')); ?>" id="search-bar" class="search-form">
                                <input type="text" name="search" placeholder="Search products" value="<?php echo e(request('search')); ?>">
                                <button type="submit" aria-label="Keresés">
                                    <i class="fa fa-search"></i>
                                </button>
                            </form>
                        </div>

                        <?php if(!Request::is('/')): ?>
                            <a href="<?php echo e(url('/')); ?>">
                                <i class="fa-solid fa-house"></i> <span>Home</span>
                            </a>
                        <?php endif; ?>

                        <?php if(auth()->check()): ?>
                            <a id="cart-icon" href="<?php echo e(route('cart.mycart')); ?>">
                                <i class="fa-solid fa-basket-shopping"></i> <span>My Cart</span>
                            </a>
                            <a id="orders-icon" href="<?php echo e(route('orders.myorders')); ?>">
                                <i class="fa-solid fa-box"></i> <span>My Orders</span>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>


            <!-- KATEGÓRIA MENÜ -->
            <div class="menu">
                <a href="<?php echo e(route('products.category', ['category' => 'Clothings'])); ?>">Club Apparel</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Jerseys'])); ?>">Club Jerseys</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Shoes'])); ?>">Football Shoes</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Balls'])); ?>">Football Balls</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Equipment'])); ?>">Football Equipment</a>
            </div>


            <!-- 📱 MOBILMENÜ különtéve (nem bal oldalon!) -->
            <div class="mobile-menu">
                <a href="<?php echo e(route('products.category', ['category' => 'Clothings'])); ?>">Club Apparel</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Jerseys'])); ?>">Club Jerseys</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Shoes'])); ?>">Football Shoes</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Balls'])); ?>">Football Balls</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Equipment'])); ?>">Football Equipment</a>
            </div>


        </nav>
    </header>
    <div>
        <?php if($recommendedProducts->count() > 0): ?>
            <section class="personal-recommendations">
                <h2>🎯 Neked ajánlott termékek</h2>
                <div class="recommendation-wrapper">
                    <button class="scroll-left" onclick="scrollRecommendations(-1)">&#10094;</button>

                    <div class="product-grid" id="recommendation-track">
                        <?php $__currentLoopData = $recommendedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('products.details', ['id' => $product->id])); ?>" class="product-card">
                                <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>">
                                <h4><?php echo e($product->name); ?></h4>
                                <p><?php echo e(number_format($product->price, 2)); ?> lei</p>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <button class="scroll-right" onclick="scrollRecommendations(1)">&#10095;</button>
                </div>
            </section>
        <?php endif; ?>

        <form method="GET" action="<?php echo e(route('home')); ?>" id="sort-form" style="margin: 20px 0;">
            <?php if(request()->filled('search')): ?>
                <input type="hidden" name="search" value="<?php echo e(request('search')); ?>">
            <?php endif; ?>

            <label for="sort">Sort by:</label>
            <select name="sort" id="sort" onchange="handleSortAndScroll()">

                <option value="">-- Choose --</option>
                <option value="price_asc" <?php echo e(request('sort') == 'price_asc' ? 'selected' : ''); ?>>Price: Low to High
                </option>
                <option value="price_desc" <?php echo e(request('sort') == 'price_desc' ? 'selected' : ''); ?>>Price: High to Low
                </option>
                <option value="name_asc" <?php echo e(request('sort') == 'name_asc' ? 'selected' : ''); ?>>Name: A-Z</option>
                <option value="name_desc" <?php echo e(request('sort') == 'name_desc' ? 'selected' : ''); ?>>Name: Z-A</option>
            </select>

            <button type="button" onclick="resetSorting()" style="margin-left: 10px;">
                Reset sorting
            </button>
        </form>
    </div>

    <main id="product-list">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('products.details', $product->id)); ?>" class="product">
                <div>
                    <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>">
                    <p><?php echo e($product->name); ?></p>
                    <p class="price"><?php echo e(number_format($product->price, 2)); ?> lei</p>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No products available at the moment.</p>
        <?php endif; ?>
    </main>

    <footer>
        <div class="footer">
            <p>All rights reserved ©Football Shop 2025</p>
        </div>
    </footer>

    <?php echo $__env->make('components.chatbot-widget', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>


</body>
</html>
<?php /**PATH D:\SAPIENTIA\ÁLLAMVIZSGA\Peter_Levente_Allamvizsga\FootballShop\resources\views/index.blade.php ENDPATH**/ ?>