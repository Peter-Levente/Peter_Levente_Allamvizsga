<!-- resources/views/index.blade.php -->

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Football Shop - Home</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/PROJECT.css')); ?>">
</head>
<body>
<div class="wrapper">
    <header>
        <nav class="header">
            <div class="title">
                <h1>Football Shop</h1>

                <div class="auth-buttons">
                    <?php if(!auth()->check()): ?> <!-- Ha nincs bejelentkezve -->
                    <a href="<?php echo e(route('login')); ?>"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
                    <a href="<?php echo e(route('register')); ?>"><i class="fa-solid fa-user-plus"></i> Registration</a>
                    <?php endif; ?>
                </div>

                <div class="auth-buttons">
                    <?php if(auth()->check()): ?> <!-- Ha be van jelentkezve -->
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="fa-solid fa-right-from-bracket"></i> Logout
                    </a>

                    <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>

                    <span class="welcome-message">Welcome, <?php echo e(auth()->user()->name); ?>!</span>
                    <?php endif; ?>
                </div>

                <div class="header-actions">
                    <!-- Home gomb csak akkor jelenik meg, ha NEM az index oldalon vagyunk -->
                    <?php if(!Request::is('/')): ?>
                        <a href="<?php echo e(url('/')); ?>" class="home-link">
                            <i class="fa-solid fa-house"></i> Home
                        </a>
                    <?php endif; ?>

                    <?php if(auth()->check()): ?> <!-- Ha be van jelentkezve -->
                    <a id="cart-icon" href="<?php echo e(route('cart.mycart')); ?>" class="header-link">
                        <i class="fa-solid fa-basket-shopping"></i> My Cart
                    </a>
                    <a id="orders-icon" href="<?php echo e(route('orders.myorders')); ?>" class="header-link">
                        <i class="fa-solid fa-box"></i> My Orders
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="menu">
                <a href="<?php echo e(route('products.category', ['category' => 'Clothings'])); ?>">Club Apparel</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Jerseys'])); ?>">Club Jerseys</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Shoes'])); ?>">Football Shoes</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Balls'])); ?>">Football Balls</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Equipment'])); ?>">Football Equipment</a>
            </div>
        </nav>
    </header>


    <div>
        <?php if($recommendedProducts->count() > 0): ?>
            <section class="personal-recommendations">
                <h2>🎯 Neked ajánlott termékek</h2>
                <div class="product-grid">
                    <?php $__currentLoopData = $recommendedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('products.details', ['id' => $product->id])); ?>" class="product-card">
                            <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>">
                            <h4><?php echo e($product->name); ?></h4>
                            <p><?php echo e(number_format($product->price, 2)); ?> lei</p>
                            <?php if(!is_null($product->distance)): ?>
                                <small style="font-size: 0.8rem; color: #666;">Távolság: <?php echo e(number_format($product->distance, 4)); ?></small>
                            <?php endif; ?>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>
    </div>

    <main>



    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('products.details', $product->id)); ?>" class="product">
                <div>
                    <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>">
                    <p><?php echo e($product->name); ?></p>
                    <p class="price"><?php echo e(number_format($product->price, 2)); ?> lei</p>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No products available at the moment.</p>
        <?php endif; ?>
    </main>

    <footer>
        <div class="footer">
            <p>All rights reserved ©Football Shop 2025</p>
        </div>
    </footer>

    
    <?php echo $__env->make('components.chatbot-widget', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
</body>
</html>
<?php /**PATH D:\SAPIENTIA\ÁLLAMVIZSGA\Peter_Levente_Allamvizsga\FootballShop\resources\views/index.blade.php ENDPATH**/ ?>