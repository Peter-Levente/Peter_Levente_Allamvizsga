<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Football Shop - Category</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="index-page category-page">
<div class="wrapper">
    <header>
        <nav class="header">
            <div class="topbar">
                <div class="center">
                    <h1>Football Shop</h1>
                </div>

                <!-- Mobil ikon-sáv -->
                <div class="icon-bar">
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">☰</button>

                    <a href="<?php echo e(url('/')); ?>"><i class="fa-solid fa-house"></i> <span></span></a>

                    <?php if(!auth()->check()): ?>
                        <a href="<?php echo e(route('login')); ?>"><i class="fa-solid fa-right-to-bracket"></i></a>
                        <a href="<?php echo e(route('register')); ?>"><i class="fa-solid fa-user-plus"></i></a>
                    <?php else: ?>
                        <a href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="fa-solid fa-right-from-bracket"></i>
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    <?php endif; ?>
                    <a href="<?php echo e(route('orders.myorders')); ?>"><i class="fa-solid fa-box"></i></a>
                    <a href="<?php echo e(route('cart.mycart')); ?>"><i class="fa-solid fa-cart-shopping"></i></a>

                    <button type="button" class="search-toggle" onclick="toggleMobileSearchBar()">
                        <i class="fa fa-search"></i>
                    </button>

                    <form method="GET" action="<?php echo e(route('home')); ?>" id="mobile-search-bar" class="search-form">
                        <input type="text" name="search" placeholder="Search products" value="<?php echo e(request('search')); ?>">
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </form>
                </div>

                <div class="left">
                    <button class="mobile-menu-toggle" onclick="toggleMobileMenu()">☰</button>
                    <div class="auth-buttons">
                        <?php if(!auth()->check()): ?>
                            <a href="<?php echo e(route('login')); ?>"><i class="fa-solid fa-right-to-bracket"></i>
                                <span>Login</span></a>
                            <a href="<?php echo e(route('register')); ?>"><i class="fa-solid fa-user-plus"></i>
                                <span>Registration</span></a>
                        <?php else: ?>
                            <a href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fa-solid fa-right-from-bracket"></i> <span>Logout</span>
                            </a>
                            <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>"
                                  style="display: none;"><?php echo csrf_field(); ?></form>
                            <span class="welcome-message">Welcome, <?php echo e(auth()->user()->name); ?>!</span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="right">
                    <div class="header-actions">
                        <div class="search-container">
                            <button type="button" class="search-toggle" onclick="toggleSearchBar()">
                                <i class="fa fa-search"></i>
                            </button>
                            <form method="GET" action="<?php echo e(route('home')); ?>" id="search-bar" class="search-form">
                                <input type="text" name="search" placeholder="Search products"
                                       value="<?php echo e(request('search')); ?>">
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>

                        <a href="<?php echo e(url('/')); ?>"><i class="fa-solid fa-house"></i> <span>Home</span></a>

                        <?php if(auth()->check()): ?>
                            <a href="<?php echo e(route('cart.mycart')); ?>"><i class="fa-solid fa-basket-shopping"></i> <span>My Cart</span></a>
                            <a href="<?php echo e(route('orders.myorders')); ?>"><i class="fa-solid fa-box"></i>
                                <span>My Orders</span></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="menu">
                <a href="<?php echo e(route('products.category', ['category' => 'Clothings'])); ?>">Club Apparel</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Jerseys'])); ?>">Club Jerseys</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Shoes'])); ?>">Football Shoes</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Balls'])); ?>">Football Balls</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Equipment'])); ?>">Football Equipment</a>
            </div>

            <div class="mobile-menu">
                <a href="<?php echo e(route('products.category', ['category' => 'Clothings'])); ?>">Club Apparel</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Jerseys'])); ?>">Club Jerseys</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Shoes'])); ?>">Football Shoes</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Balls'])); ?>">Football Balls</a>
                <a href="<?php echo e(route('products.category', ['category' => 'Equipment'])); ?>">Football Equipment</a>
            </div>
        </nav>
    </header>

    <div>
        <form method="GET" action="<?php echo e(url()->current()); ?>" id="sort-form" style="margin: 20px 0;">
            <label for="sort">Sort by:</label>
            <select name="sort" id="sort" onchange="handleSortAndScroll()">
                <option value="">-- Choose --</option>
                <option value="price_asc" <?php echo e(request('sort') == 'price_asc' ? 'selected' : ''); ?>>Price: Low to High
                </option>
                <option value="price_desc" <?php echo e(request('sort') == 'price_desc' ? 'selected' : ''); ?>>Price: High to Low
                </option>
                <option value="name_asc" <?php echo e(request('sort') == 'name_asc' ? 'selected' : ''); ?>>Name: A-Z</option>
                <option value="name_desc" <?php echo e(request('sort') == 'name_desc' ? 'selected' : ''); ?>>Name: Z-A</option>
            </select>
            <button type="button" onclick="resetSorting()" style="margin-left: 10px;">Reset sorting</button>
        </form>
    </div>

    <main id="product-list">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('products.details', $product->id)); ?>" class="product">
                <div>
                    <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>">
                    <p><?php echo e($product->name); ?></p>
                    <p class="price"><?php echo e(number_format($product->price, 2)); ?> lei</p>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No products available at the moment.</p>
        <?php endif; ?>
    </main>

    <footer>
        <div class="footer">
            <p>All rights reserved ©Football Shop 2025</p>
        </div>
    </footer>

    <?php echo $__env->make('components.chatbot-widget', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
</body>
</html>
<?php /**PATH D:\SAPIENTIA\ÁLLAMVIZSGA\Peter_Levente_Allamvizsga\FootballShop\resources\views/products/category.blade.php ENDPATH**/ ?>