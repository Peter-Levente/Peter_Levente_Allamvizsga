<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thank You</title>
    <!-- Külső CSS fájl betöltése -->
    <link rel="stylesheet" href="<?php echo e(asset('css/thank_you.css')); ?>">
</head>
<body>
<div class="container">
    <h1>Thank You for Your Order!</h1>
    <!-- Az order_id megjelenítése -->
    <p>Your order ID is: <?php echo e($order->id); ?></p>
    <!-- Visszairányítás a főoldalra -->
    <a href="<?php echo e(route('home')); ?>">Go back to homepage</a>
</div>

<?php if($recommendedProducts->isNotEmpty()): ?>
    <section class="recommended-thankyou">
        <h3>🎁 Ajánlott termékek a következő vásárlásodhoz</h3>
        <div class="product-grid">
            <?php $__currentLoopData = $recommendedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('products.details', ['id' => $product->id])); ?>" class="product-card">
                    <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>">
                    <h4><?php echo e($product->name); ?></h4>
                    <p><?php echo e(number_format($product->price, 2)); ?> lei</p>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php endif; ?>


</body>
</html>
<?php /**PATH D:\SAPIENTIA\ÁLLAMVIZSGA\Peter_Levente_Allamvizsga\FootballShop\resources\views/orders/thank_you.blade.php ENDPATH**/ ?>